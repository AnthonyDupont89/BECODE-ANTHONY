const swiper = new Swiper('.swiper', {
  slidesPerView: 4,
  loop: true,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev'
  }
})



// ?api_key=4f04fe8716e810a21478e238e8c9c7d2

console.log("test");

